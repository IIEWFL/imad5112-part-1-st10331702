package com.example.calculator_imad5112

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {

    private var insert1: TextView? = null
    private var insert2: TextView? = null
    private var result: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        insert1 = findViewById(R.id.number1)
        insert2 = findViewById(R.id.number2)
        result = findViewById(R.id.tvAnswer)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSub = findViewById<Button>(R.id.btnSub)
        val btnMul = findViewById<Button>(R.id.btnMul)
        val btnDiv = findViewById<Button>(R.id.btnDiv)
        val btnSqr = findViewById<Button>(R.id.btnSqr)
        val btnPow = findViewById<Button>(R.id.btnPow)
        val btnStat = findViewById<Button>(R.id.btnStat)

        btnAdd.setOnClickListener {
            add()
        }
        btnSub.setOnClickListener {
            subtract()
        }
        btnMul.setOnClickListener {
            multiply()
        }
        btnDiv.setOnClickListener {
            divide()
        }
        btnSqr.setOnClickListener {
            squareRoot()

        }

        btnPow.setOnClickListener {
            power()
        }
        btnStat.setOnClickListener {
            statistics()

        }

    }

    private fun add() {
        if (isNotEmpty()) {

            val input1 = insert1?.text.toString().trim().toBigDecimal()
            val input2 = insert2?.text.toString().trim().toBigDecimal()
            result?.text = input1.add(input2).toString()
        }
    }

    private fun isNotEmpty(): Boolean {

        var b = true
        if (insert1?.text.toString().trim().isEmpty()) {

            insert1?.error = "Required"
            b = false
        }
        if (insert2?.text.toString().trim().isEmpty()) {

            insert2?.error = "Required"
            b = false
        }
        return b

    }

    private fun subtract() {
        if (isNotEmpty()) {

            val input1 = insert1?.text.toString().trim().toBigDecimal()
            val input2 = insert2?.text.toString().trim().toBigDecimal()
            result?.text = input1.subtract(input2).toString()
        }
    }

    private fun multiply() {
        if (isNotEmpty()) {

            val input1 = insert1?.text.toString().trim().toBigDecimal()
            val input2 = insert2?.text.toString().trim().toBigDecimal()
            result?.text = input1.multiply(input2).toString()
        }
    }

    private fun divide() {
        if (isNotEmpty()) {

            var input1 = insert1?.text.toString().trim().toBigDecimal()
            var input2 = insert2?.text.toString().trim().toBigDecimal()

            if (input1 == BigDecimal.ZERO || input2 == BigDecimal.ZERO) {
                result?.text = "Please enter a number bigger than zero."
            } else {
                var answer = input1.divide(input2, 2, RoundingMode.HALF_UP)
                result?.text = "$input1 / $input2 = $answer"

            }
        }
    }

    private fun squareRoot() {

    }

    private fun power() {

    }

    private fun statistics() {

    }
}